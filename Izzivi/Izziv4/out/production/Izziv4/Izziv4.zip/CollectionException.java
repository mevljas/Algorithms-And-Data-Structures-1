class CollectionException extends Exception {
    public CollectionException(String msg) {
        super(msg);
    }
}