public class LinkedHeapPQ<T extends Comparable> implements PriorityQueue<T> {
    private Node node;
    private int size = 0;
    private int moveCounter = 0;
    private int compareCounter = 0;

    public LinkedHeapPQ() {
    }


    @Override
    public T front() throws CollectionException {
        System.out.println(node.item);
        return (T) node.item;
    }

    @Override
    public void enqueue(T x) {
        if (node == null) {
            this.node = new Node();
            node.item = x;
            moveCounter++;
        } else {
            String bin = Integer.toBinaryString(size + 1);
            bin = bin.substring(1);
            Node newNode = node;
            for (int i = 0; i < bin.length(); i++) {
                if (bin.charAt(i) == '0') {
                    if (newNode.left == null) {
                        newNode.left = new Node();
                        newNode.left.parent = newNode;
                    }
                    newNode = newNode.left;
                } else if (bin.charAt(i) == '1') {
                    if (newNode.right == null) {
                        newNode.right = new Node();
                        newNode.right.parent = newNode;
                    }
                    newNode = newNode.right;
                }
            }
            newNode.item = x;
            moveCounter++;

            if (parent(newNode) != null) {
                compareCounter++;
                while (newNode.item.compareTo(parent(newNode).item) > 0) {
                    swap(newNode, parent(newNode));
                    newNode = parent(newNode);
                    if (parent(newNode) == null)
                        break;
                    compareCounter++;
                }
            }

        }
        size++;
    }


    @Override
    public T dequeue() throws CollectionException {
        T popped = (T) node.item;
        String bin = Integer.toBinaryString(size);
        bin = bin.substring(1);
        Node lastNode = node;
        for (int i = 0; i < bin.length(); i++) {
            if (bin.charAt(i) == '0') {
                lastNode = lastNode.left;
            } else if (bin.charAt(i) == '1') {
                lastNode = lastNode.right;
            }
        }
        node.item = lastNode.item;
        moveCounter++;
        size--;
        maxHeapify(node);
        return popped;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }


    private Node parent(Node element) {
        return element.parent;
    }

    private Node leftChild(Node element) {
        return element.left;
    }

    private Node rightChild(Node element) {
        return element.right;
    }

    private boolean isLeaf(Node element) {
        return (element.right == null && element.left == null);
    }

    private void swap(Node first, Node second) {
        T tmp;
        tmp = (T) first.item;
        first.item = second.item;
        second.item = tmp;
        moveCounter++;
        moveCounter++;
    }

    private void maxHeapify(Node n) {
        if (isLeaf(n))
            return;


        if (leftChild(n) != null) {

            compareCounter++;

            if (n.item.compareTo(leftChild(n).item) < 0) {

                swap(n, leftChild(n));
                maxHeapify(leftChild(n));
            }
        } else if (rightChild(n) != null) {

            compareCounter++;

            if (n.item.compareTo(rightChild(n).item) < 0) {

                swap(n, rightChild(n));
                maxHeapify(rightChild(n));
            }
        }

    }


    public int getMoveCounter() {
        return moveCounter;
    }

    public int getCompareCounter() {
        return compareCounter;
    }
}
