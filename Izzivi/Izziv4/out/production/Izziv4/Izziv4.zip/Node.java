public class Node<T extends Comparable> {
    T item;
    Node left, right, parent;

    public Node(){
    }
}
