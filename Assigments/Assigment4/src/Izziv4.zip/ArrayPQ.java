public class ArrayPQ<T extends Comparable> implements PriorityQueue<T> {
    private static final int DEFAULT_CAPACITY = 64;
    private T[] array;
    private int size = 0;
    private int moveCounter = 0;
    private int compareCounter = 0;

    public ArrayPQ() {
        this.array = (T[]) (new Comparable[DEFAULT_CAPACITY]);
    }


    @Override
    public T front() {
        T max = array[0];
        moveCounter++;
        for (int i = 0; i < size; i++) {
            compareCounter++;
            if (array[i].compareTo(max) > 0) {
                max = array[i];
                moveCounter++;

            }
        }
        System.out.println(max);
        return max;
    }

    @Override
    public void enqueue(T x) {
        if (size == array.length) {
            resize();
        }
        array[size++] = x;
        moveCounter++;
    }

    @Override
    public T dequeue() {
        int index = 0;
        T max = array[0];
        moveCounter++;
        for (int i = 0; i < size; i++) {
            compareCounter++;
            if (array[i].compareTo(max) > 0) {
                max = array[i];
                moveCounter++;
                index = i;
            }
        }
        if (index != size - 1) {
            array[index] = array[size - 1];
            moveCounter++;
        }
        array[--size] = null;
        return max;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }


    private void resize() {
        T[] array2 = (T[]) (new Comparable[array.length * 2]);
        for (int i = 0; i < array.length; i++) {
            array2[i] = array[i];
            moveCounter++;
        }
        this.array = array2;
    }

    public int getMoveCounter() {
        return moveCounter;
    }

    public int getCompareCounter() {
        return compareCounter;
    }
}
